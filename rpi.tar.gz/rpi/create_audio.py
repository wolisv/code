from gtts import gTTS
import os

def save_numbers_as_audio(start, end):
    for num in range(start, end+1):
        text = str(num)
        tts = gTTS(text=text, lang='ko')
        filename = f'{num}.mp3'
        tts.save(filename)

# 1에서 99까지의 숫자를 음성으로 저장
save_numbers_as_audio(1, 99)
