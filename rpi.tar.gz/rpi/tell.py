from playsound import playsound
import os

# 이동할 디렉토리 경로
new_directory = "./audio"

# 디렉토리 변경
os.chdir(new_directory)

def play_sounds(files):
    for file in files:
        playsound(file)

# 여러 개의 오디오 파일 경로 리스트
audio_files = ["front.mp3", "63.mp3", "m.mp3"]

# 오디오 파일 재생
play_sounds(audio_files)