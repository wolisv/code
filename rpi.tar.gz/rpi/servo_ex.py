import RPi.GPIO as GPIO  # RPi.GPIO 라이브러리를 GPIO로 임포트합니다.
import time             # time 모듈을 임포트합니다.

# GPIO 핀 번호 설정
servo_pin = 18          # SG90 서보모터가 연결된 GPIO 핀 번호를 변수에 저장합니다.

# GPIO 핀 번호 할당 방식 설정
GPIO.setmode(GPIO.BCM)  # GPIO 핀 번호를 BCM 모드로 설정합니다. 다른 설정 방식도 사용 가능합니다.

# 서보모터 핀을 출력으로 설정
GPIO.setup(servo_pin, GPIO.OUT)  # 서보모터 핀을 출력 모드로 설정합니다.

# PWM 객체 생성: 핀 번호와 주파수 설정
pwm = GPIO.PWM(servo_pin, 50)    # PWM 객체를 생성합니다. 주파수는 50Hz로 설정합니다.

# PWM 신호 생성 시작
pwm.start(0)                      # PWM 신호를 생성합니다. 초기 듀티 사이클은 0으로 설정합니다.

def set_angle(angle):            # 각도를 설정하는 함수를 정의합니다.
    duty = (angle / 18) + 2.5    # 주어진 각도에 따라 듀티 사이클을 계산합니다.
    pwm.ChangeDutyCycle(duty)    # 계산된 듀티 사이클로 PWM을 변경합니다.
    time.sleep(1)                # 1초 동안 대기합니다.

try:
    while True:                  # 무한 루프를 시작합니다.
        # 0도로 이동
        set_angle(0)             # 서보모터를 0도로 이동합니다.
        time.sleep(1)            # 1초 동안 대기합니다.
        # 90도로 이동
        set_angle(90)            # 서보모터를 90도로 이동합니다.
        time.sleep(1)            # 1초 동안 대기합니다.
        # 180도로 이동
        set_angle(180)           # 서보모터를 180도로 이동합니다.
        time.sleep(1)            # 1초 동안 대기합니다.

except KeyboardInterrupt:      # 사용자가 Ctrl+C 키를 눌렀을 때 실행됩니다.
    # 프로그램 종료 시 GPIO 리소스 정리
    pwm.stop()                 # PWM을 중지합니다.
    GPIO.cleanup()             # GPIO 리소스를 정리합니다.
