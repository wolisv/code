import RPi.GPIO as GPIO  # RPi.GPIO 라이브러리를 GPIO라는 이름으로 가져옴
import time  # 시간과 관련된 함수를 제공하는 time 모듈을 가져옴

# 초음파 속도 상수 (cm/us) (온도 보정 포함)
def VELOCITY_TEMP(temp):
    return (331.5 + 0.6 * temp) * 100 / 1000000.0

trigechoPin = 11  # 초음파 센서의 트리거 핀 및 에코 핀을 GPIO 핀 번호 11로 설정

def setup():
    GPIO.setmode(GPIO.BOARD)  # GPIO 핀 번호를 보드 상의 번호로 설정
    GPIO.setup(trigechoPin, GPIO.OUT)  # 초음파 센서의 트리거 핀을 출력으로 설정
    GPIO.output(trigechoPin, GPIO.LOW)  # 초음파 센서의 트리거 핀을 LOW로 초기화
    time.sleep(0.1)  # 0.1초 동안 대기
    print("Ultrasonic sensor initialized.")  # "Ultrasonic sensor initialized."를 출력

def loop():
    while True:  # 무한 루프 시작
        GPIO.output(trigechoPin, GPIO.HIGH)  # 트리거 신호를 HIGH로 설정
        time.sleep(0.00001)  # 10 마이크로초(초음파 센서 제어) 동안 대기
        GPIO.output(trigechoPin, GPIO.LOW)  # 트리거 신호를 LOW로 설정

        GPIO.setup(trigechoPin, GPIO.IN)  # 초음파 센서의 에코 핀을 입력으로 설정
        pulse_start = time.time()  # 펄스의 시작 시간 기록
        pulse_end = time.time()  # 펄스의 종료 시간 기록

        while GPIO.input(trigechoPin) == 0:  # 에코 핀이 LOW인 동안
            pulse_start = time.time()  # 펄스의 시작 시간을 현재 시간으로 업데이트

        while GPIO.input(trigechoPin) == 1:  # 에코 핀이 HIGH인 동안
            pulse_end = time.time()  # 펄스의 종료 시간을 현재 시간으로 업데이트

        pulse_duration = pulse_end - pulse_start  # 초음파 파형 신호의 시간 간격을 측정
        distance = pulse_duration * VELOCITY_TEMP(20) / 2.0  # 거리 계산, 온도 값을 VELOCITY_TEMP 함수에 전달
        distance = round(distance, 2)  # 소수점 둘째자리까지 반올림

        print("Distance:", distance, "cm")  # 거리를 출력
        time.sleep(0.5)  # 0.5초 동안 대기

def destroy():
    GPIO.cleanup()  # GPIO 리소스 정리

if __name__ == "__main__":
    setup()  # 초기화 함수 호출
    try:
        loop()  # 무한 루프 함수 호출
    except KeyboardInterrupt:
        destroy()  # 종료 시 GPIO 리소스 정리 함수 호출